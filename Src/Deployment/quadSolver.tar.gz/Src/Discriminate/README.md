Directory for Discriminate which calculates the discriminate for the solver 

There are 2 functions in the discriminate.c.  One returns the value of the discriminate (discriminateVal, and the other returns 0, 1, and 2 which means no real solutions (complex)(discriminateRoots), double root, and 2 real solutions respectively.

T1 tests the returned discriminate value
T2 tests the returned code for #/type of roots