Directory for Formatting Output 

The main function in formatoutput.c will format the returning real roots, complex roots, and double roots in a readable format then print to command line
