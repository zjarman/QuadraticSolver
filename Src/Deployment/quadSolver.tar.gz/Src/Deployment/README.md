Deployment Directory

***Always run make clean before any other make commands***

This directory will house the tar file generated from the Solver folder's makefile.  This file can be untarred onto user's computer and the inside's make file will generate the executable along with 


Makefile commands

make a.out: make the program
make d.out: make the program along with debug information
make clean: clean object and output file (RUN THIS FIRST)
