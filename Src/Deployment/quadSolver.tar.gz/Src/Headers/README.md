Headers directory

The allheaders.h file in this directory will include all headers needed for quadratic solver.  The main quadratic solver program will call this header to run needed functionality