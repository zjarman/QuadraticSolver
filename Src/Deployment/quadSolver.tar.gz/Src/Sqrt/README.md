Directory for Sqrt function which will execute and return sqrt equation
