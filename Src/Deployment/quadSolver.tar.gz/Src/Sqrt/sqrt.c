#include <stdio.h>
#include <math.h>

/*Prototypes*/
double mysqrt(double value);

double mysqrt(double value){
	return sqrt(value);
}
