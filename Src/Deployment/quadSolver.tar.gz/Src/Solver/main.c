#include <stdio.h>
#include <stdlib.h>
#include "quadsolver.h"

int main(){
	/*Run Quadratic Solver*/
	quadsolver();

	return 0;
}