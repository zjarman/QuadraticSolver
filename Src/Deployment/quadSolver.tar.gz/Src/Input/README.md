Directory for Input which accepts input from the user

The main method in the input.c file (getUserInput) accepts a string from calling function
which will be the prompt for the user.  The user's iput will be passed back to the function calling the getUserInput function